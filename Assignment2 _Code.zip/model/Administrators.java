// Administrators.java

package model;

// Child of Account
public class Administrators extends Account {
    
    public Administrators(String n, String un, String p){

        super(n, un, p);
    }
}
